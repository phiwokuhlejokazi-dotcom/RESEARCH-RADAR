class CustomHeader extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
        }
        
        header {
          background: rgba(17, 24, 39, 0.8);
          backdrop-filter: blur(10px);
          border-bottom: 1px solid rgba(34, 197, 94, 0.2);
          padding: 1rem 0;
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .logo {
          display: flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
        }
        
        .logo-icon {
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #10b981, #3b82f6);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        }
        
        .logo-text {
          font-size: 1.5rem;
          font-weight: 700;
          background: linear-gradient(90deg, #10b981, #3b82f6);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        
        nav ul {
          display: flex;
          list-style: none;
          gap: 2rem;
        }
        
        nav a {
          color: #9ca3af;
          text-decoration: none;
          font-weight: 500;
          transition: color 0.3s ease;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        
        nav a:hover {
          color: #10b981;
        }
        
        nav a.active {
          color: #10b981;
        }
        
        @media (max-width: 768px) {
          .container {
            flex-direction: column;
            gap: 1rem;
          }
          
          nav ul {
            gap: 1rem;
          }
        }
      </style>
      
      <header>
        <div class="container">
          <a href="/" class="logo">
            <div class="logo-icon">
              <i data-feather="radio"></i>
            </div>
            <div class="logo-text">Research Radar</div>
          </a>
          
          <nav>
            <ul>
              <li><a href="/" class="active"><i data-feather="home"></i> Home</a></li>
              <li><a href="#"><i data-feather="book"></i> Resources</a></li>
              <li><a href="#"><i data-feather="info"></i> About</a></li>
            </ul>
          </nav>
        </div>
      </header>
    `;
    
    // Load feather icons
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/feather-icons';
    script.onload = () => {
      feather.replace();
    };
    this.shadowRoot.appendChild(script);
  }
}

customElements.define('custom-header', CustomHeader);