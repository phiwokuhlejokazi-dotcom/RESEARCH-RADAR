class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          margin-top: 4rem;
        }
        
        footer {
          background: rgba(17, 24, 39, 0.8);
          backdrop-filter: blur(10px);
          border-top: 1px solid rgba(34, 197, 94, 0.2);
          padding: 2rem 0;
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
        }
        
        .footer-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 1.5rem;
          text-align: center;
        }
        
        .logo {
          display: flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
        }
        
        .logo-icon {
          width: 36px;
          height: 36px;
          background: linear-gradient(135deg, #10b981, #3b82f6);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        }
        
        .logo-text {
          font-size: 1.25rem;
          font-weight: 700;
          background: linear-gradient(90deg, #10b981, #3b82f6);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        
        .footer-links {
          display: flex;
          gap: 2rem;
          flex-wrap: wrap;
          justify-content: center;
        }
        
        .footer-links a {
          color: #9ca3af;
          text-decoration: none;
          transition: color 0.3s ease;
        }
        
        .footer-links a:hover {
          color: #10b981;
        }
        
        .copyright {
          color: #6b7280;
          font-size: 0.875rem;
          margin-top: 1rem;
        }
        
        @media (max-width: 768px) {
          .footer-links {
            gap: 1rem;
          }
        }
      </style>
      
      <footer>
        <div class="container">
          <div class="footer-content">
            <a href="/" class="logo">
              <div class="logo-icon">
                <i data-feather="radio"></i>
              </div>
              <div class="logo-text">Research Radar</div>
            </a>
            
            <div class="footer-links">
              <a href="#"><i data-feather="home" class="mr-2"></i> Home</a>
              <a href="#"><i data-feather="book" class="mr-2"></i> Resources</a>
              <a href="#"><i data-feather="info" class="mr-2"></i> About</a>
              <a href="#"><i data-feather="mail" class="mr-2"></i> Contact</a>
            </div>
            
            <p class="copyright">
              &copy; 2023 Research Radar. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    `;
    
    // Load feather icons
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/feather-icons';
    script.onload = () => {
      feather.replace();
    };
    this.shadowRoot.appendChild(script);
  }
}

customElements.define('custom-footer', CustomFooter);