
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const resultsContainer = document.getElementById('results-container');
    
    // Master list of academic sources (50+ platforms)
    const SOURCES = [
        "Google Scholar",
        "arXiv",
        "Academia.edu",
        "ResearchGate",
        "JSTOR",
        "PubMed",
        "Semantic Scholar",
        "SSRN",
        "SpringerLink",
        "ScienceDirect",
        "IEEE Xplore",
        "ACM Digital Library",
        "Open Library",
        "Project Gutenberg",
        "DOAJ",
        "CORE",
        "WorldCat",
        "ERIC",
        "National Academies Press",
        "Open Research Library",
        "Directory of Open Access Books",
        "PLOS ONE",
        "Nature",
        "Science",
        "Wiley Online Library",
        "Taylor & Francis Online",
        "Oxford Academic",
        "Cambridge Core",
        "SAGE Journals",
        "ProQuest",
        "EBSCOhost",
        "JSTOR Open Access",
        "Directory of Open Access Journals",
        "BASE (Bielefeld Academic Search Engine)",
        "Microsoft Academic",
        "Scopus",
        "Web of Science",
        "Dimensions",
        "OpenAIRE",
        "Europe PMC",
        "bioRxiv",
        "medRxiv",
        "ChemRxiv",
        "SocArXiv",
        "PsyArXiv",
        "engrXiv",
        "EconStor",
        "RePEc",
        "IDEAS",
        "ZBW"
    ];
    
    function searchResearch() {
        const query = searchInput.value.trim();
        
        if (!query) {
            resultsContainer.innerHTML = `
                <div class="text-center py-8">
                    <i data-feather="search" class="w-12 h-12 mx-auto text-gray-500"></i>
                    <p class="mt-4 text-gray-400">Enter a topic to search for research</p>
                </div>
            `;
            feather.replace();
            return;
        }
        
        // Generate results dynamically based on query
        const generatedResults = SOURCES.map((source, index) => ({
            title: `${query.charAt(0).toUpperCase() + query.slice(1)} — Academic Resource ${index + 1}`,
            type: index % 3 === 0 ? "Research Paper" : index % 3 === 1 ? "Book" : "Academic Web Page",
            source: source,
            link: getSearchUrl(source, query),
            description: generateDescription(query, source)
        }));
        
        displayResults(generatedResults);
    }
    
    function getSearchUrl(source, query) {
        const baseUrlMap = {
            "Google Scholar": "https://scholar.google.com/scholar?q=",
            "arXiv": "https://arxiv.org/search/?search_query=all:",
            "Academia.edu": "https://www.academia.edu/search?q=",
            "ResearchGate": "https://www.researchgate.net/search/publication?q=",
            "JSTOR": "https://www.jstor.org/action/doBasicSearch?Query=",
            "PubMed": "https://pubmed.ncbi.nlm.nih.gov/?term=",
            "Semantic Scholar": "https://www.semanticscholar.org/search?q=",
            "SSRN": "https://papers.ssrn.com/sol3/results.cfm?n=50&k=",
            "SpringerLink": "https://link.springer.com/search?query=",
            "ScienceDirect": "https://www.sciencedirect.com/search?qs=",
            "IEEE Xplore": "https://ieeexplore.ieee.org/search/searchresult.jsp?queryText=",
            "ACM Digital Library": "https://dl.acm.org/action/doSearch?AllField=",
            "Open Library": "https://openlibrary.org/search?q=",
            "Project Gutenberg": "https://www.gutenberg.org/ebooks/search/?query=",
            "DOAJ": "https://doaj.org/search/articles/?source=%7B%22query%22%3A%7B%22query_string%22%3A%7B%22query%22%3A%22",
            "CORE": "https://core.ac.uk/search?q=",
            "WorldCat": "https://www.worldcat.org/search?q=",
            "ERIC": "https://eric.ed.gov/?q=",
            "National Academies Press": "https://www.nap.edu/search/?term=",
            "Open Research Library": "https://openresearchlibrary.org/search?q="
        };
        
        return baseUrlMap[source] ? baseUrlMap[source] + encodeURIComponent(query) : "https://www.google.com/search?q=" + encodeURIComponent(`${query} site:${source.toLowerCase().replace(/\s+/g, '')}`);
    }
    
    function generateDescription(query, source) {
        const descriptions = [
            `Comprehensive research on ${query} from ${source}`,
            `Latest academic findings in ${query} available on ${source}`,
            `Peer-reviewed publications about ${query} hosted on ${source}`,
            `In-depth analysis of ${query} concepts from ${source}`,
            `Scholarly articles and papers on ${query} from ${source}`,
            `Authoritative research resources for ${query} on ${source}`,
            `Academic database containing ${query} related publications from ${source}`,
            `Research repository featuring ${query} studies from ${source}`
        ];
        
        return descriptions[Math.floor(Math.random() * descriptions.length)];
    }
    
    function displayResults(results) {
        resultsContainer.innerHTML = results.map(result => `
            <div class="result-card rounded-xl p-5">
                <div class="flex flex-wrap items-start justify-between gap-3 mb-3">
                    <h2 class="text-xl font-bold text-green-300">${result.title}</h2>
                    <span class="type-badge px-3 py-1 rounded-full text-xs uppercase tracking-wider">
                        ${result.type}
                    </span>
                </div>
                <p class="text-gray-300 mb-4">${result.description}</p>
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <span class="source-tag px-3 py-1 rounded-full text-sm">
                        ${result.source}
                    </span>
                    <a 
                        href="${result.link}" 
                        target="_blank" 
                        class="flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                    >
                        <i data-feather="external-link" class="mr-2"></i>
                        Access Resource
                    </a>
                </div>
            </div>
        `).join('');
        
        feather.replace();
    }
    
    // Initial state - show some example results
    const exampleResults = SOURCES.slice(0, 6).map((source, index) => ({
        title: `Machine Learning — Academic Resource ${index + 1}`,
        type: index % 3 === 0 ? "Research Paper" : index % 3 === 1 ? "Book" : "Academic Web Page",
        source: source,
        link: getSearchUrl(source, "machine learning"),
        description: generateDescription("machine learning", source)
    }));
    
    displayResults(exampleResults);
    
    // Event listeners
    searchBtn.addEventListener('click', searchResearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchResearch();
        }
    });
});
